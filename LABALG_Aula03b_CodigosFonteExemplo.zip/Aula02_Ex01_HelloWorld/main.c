#include <stdio.h>
#include <stdlib.h>

/* Mar�al, J.
 * Exemplo de programa em C.
 */

int main(int argc, char *argv[]) {

	// printf - m�todo de impress�o na tela.
	printf("Hello world!");

	return 0;
}
